#!/bin/bash -u


 for mtype in {3..3}
 do

cp /glade/work/jkim/CMAQ/merge_bias/o3/p_M${mtype}/* /glade/work/jkim/CMAQ/merge_bias/o3/

    for mon in {01..12}
    do

      for day in {01..31}
      do

        date=2021${mon}${day}

        for time in {00..23}
        do

ln -sf /glade/campaign/ral/nsap/JTTI/merge/ratio_in/ratio_in_${date}${time}_o3_static.txt ./ratio_in.txt
ln -sf /glade/campaign/ral/nsap/JTTI/merge/ratio_in/ratio_in_zero_${date}${time}_o3_static.txt ./ratio_zero.txt
ln -sf /glade/scratch/jkim/CMAQ/nc_pm25_o3_cams_cmaq_grid/cams_o3_pm25_regrid_cmaq_${date}_${time}00.nc ./cams_o3_pm25_regrid_cmaq.nc

./ratio.exe

./weighter.exe

./weighter_2.exe

./weighter_3.exe

./merger.exe

mv ./cams_o3_regrid_cmaq_merged.nc /glade/scratch/jkim/CMAQ/BM${mtype}/cams_o3_regrid_cmaq_${date}_${time}00_BM${mtype}_static_include0.nc
rm /glade/work/jkim/CMAQ/merge_bias/o3/ratio_out.txt

        done
      done
    done
  done
