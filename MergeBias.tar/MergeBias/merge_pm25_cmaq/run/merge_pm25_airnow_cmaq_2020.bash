#!/bin/bash -u


# 2020
 for mtype in {3..3}
 do

cp /glade/work/jkim/CMAQ/merge_bias/pm25_cmaq/p_M${mtype}/* /glade/work/jkim/CMAQ/merge_bias/pm25_cmaq/

    for mon in {08..12}
    do

    for day in {01..31}
    do

      date=2020${mon}${day}

      for time in {00..23}
      do

ln -sf /glade/campaign/ral/nsap/JTTI/merge/ratio_in/ratio_in_${date}${time}_pm25_static_cmaq.txt ./ratio_in.txt
ln -sf /glade/campaign/ral/nsap/JTTI/merge/ratio_in/ratio_in_zero_${date}${time}_pm25_static_cmaq.txt ./ratio_zero.txt
ln -sf /glade/campaign/ral/nsap/JTTI/bcdata/cmaq_hourly/cmaq_airnow_pm2.5_o3_${date}${time}.nc ./cmaq_o3_pm25.nc

./ratio.exe

./weighter.exe

./weighter_2.exe

./weighter_3.exe

./merger.exe

mv ./cmaq_pm25_merged.nc /glade/campaign/ral/nsap/JTTI/merge/BM${mtype}/static/cmaq_include0_nn/cmaq_pm25_${date}_${time}00_BM${mtype}_static_noQC.nc
rm /glade/work/jkim/CMAQ/merge_bias/pm25_cmaq/ratio_out.txt

      done
    done
    done
  done

