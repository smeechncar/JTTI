#!/bin/bash -u

#  For each forecast lead time and run, compute the field resulting from AnEn output to the original CMAQ field (PM25).

cp /glade/work/jkim/CMAQ/merge_bias/pm25_cmaq/p_M3/* /glade/work/jkim/CMAQ/merge_bias/pm25_cmaq/

    for mon in {01..12}
    do

    for day in {01..31}
    do

      date=2021${mon}${day}

      for time in {00..72}
      do

ln -sf /glade/scratch/jkim/CMAQ/ratio_in_73lt_pm25_final/ratio_in_${date}_LT${time}_pm25.txt ./ratio_in.txt
ln -sf /glade/scratch/jkim/CMAQ/ratio_in_73lt_pm25_final/ratio_in_zero_${date}_LT${time}_pm25.txt ./ratio_zero.txt
ln -sf /glade/scratch/jkim/CMAQ/cmaq_06z_hourly/cmaq_pm2.5_o3_06z_${date}_LT${time}.nc ./cmaq_o3_pm25.nc

./ratio.exe

./weighter.exe

./weighter_2.exe

./weighter_3.exe

./merger.exe

mv ./cmaq_pm25_merged.nc /glade/scratch/jkim/CMAQ/bm3_cmaq_anen_pm25_final/cmaq_pm25_AnEn_bm3_${date}_06z_LT${time}00.nc
rm /glade/work/jkim/CMAQ/merge_bias/pm25_cmaq/ratio_out.txt

      done
    done
    done
