#!/bin/bash -u


 for mtype in {3..3}
 do

cp /glade/work/jkim/CMAQ/merge_bias/o3_cmaq/p_M${mtype}/* /glade/work/jkim/CMAQ/merge_bias/o3_cmaq/

    for mon in {08..12}
    do

    for day in {01..31}
    do

      date=2020${mon}${day}

      for time in {00..23}
      do

ln -sf /glade/campaign/ral/nsap/JTTI/merge/ratio_in/ratio_in_${date}${time}_o3_static_cmaq.txt ./ratio_in.txt
ln -sf /glade/campaign/ral/nsap/JTTI/merge/ratio_in/ratio_in_zero_${date}${time}_o3_static_cmaq.txt ./ratio_zero.txt
ln -sf /glade/campaign/ral/nsap/JTTI/bcdata/cmaq_hourly/cmaq_airnow_pm2.5_o3_${date}${time}.nc ./cmaq_o3_pm25.nc

./ratio.exe

./weighter.exe

./weighter_2.exe

./weighter_3.exe

./merger.exe

mv ./cmaq_o3_merged.nc /glade/campaign/ral/nsap/JTTI/merge/BM${mtype}/static/cmaq_include0_nn/cmaq_o3_${date}_${time}00_BM${mtype}_static_inc0_nn.nc
rm /glade/work/jkim/CMAQ/merge_bias/o3_cmaq/ratio_out.txt
      done
    done
    done
  done
